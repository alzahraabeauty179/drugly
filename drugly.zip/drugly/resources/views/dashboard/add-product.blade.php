@extends('dashboard.layouts.app')

{{-- @section('title', __('site.' . $module_name_plural . '.add')) --}}

@section('content')
<h1>empty</h1>
@endsection