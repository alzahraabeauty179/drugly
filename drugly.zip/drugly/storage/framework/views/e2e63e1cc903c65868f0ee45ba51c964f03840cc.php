<?php if(auth()->user()->can('update-'.$module_name_plural)): ?>
<a href="<?php echo e(route('dashboard.'.$module_name_plural.'.edit', $row)); ?>" title="<?php echo app('translator')->get('site.delete'); ?>" class="btn btn-info btn-sm"
    data-original-title="<?php echo app('translator')->get('site.edit'); ?> <?php echo app('translator')->get('site.'.$module_name_singular); ?>">
    <i class="fa fa-edit"> <?php echo app('translator')->get('site.edit'); ?> </i>
</a>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/buttons/edit.blade.php ENDPATH**/ ?>