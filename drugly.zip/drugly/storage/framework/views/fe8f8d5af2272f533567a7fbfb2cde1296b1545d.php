<!-- Start / Sidebar-left -->

<div class="main-menu menu-fixed menu-light menu-accordion" data-scroll-to-active="true">
    <div class="main-menu-content">
        <ul class="navigation navigation-main" id="main-menu-navigation" data-menu="menu-navigation">

            <li class="navigation-header">
                <span>General</span><i class="ft-minus" data-toggle="tooltip" data-placement="left"
                    data-original-title="General"></i>
            </li>

            <li class="nav-item">
                <a href="index.html"><i class="ft-home"></i><span class="menu-title" data-i18n="">Dashboard</span></a>
                <ul class="menu-content">
                    <li class="active"><a class="menu-item" href="#">Setting</a></li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                </ul>
            </li>

            <li class="navigation-header">
                <span><?php echo app('translator')->get('site.' . auth()->user()->type); ?></span>
                <i class="ft-minus" data-toggle="tooltip" data-placement="left"
                    data-original-title="<?php echo app('translator')->get('site.' . auth()->user()->type); ?>"></i>
            </li>

            <?php if(auth()->user()->can('read-areas')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.areas.index')); ?>"><i
                        class="ft-globe"></i><span class="menu-title"
                        data-i18n=""><?php echo app('translator')->get('site.areas'); ?></span></a>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('read-roles')): ?>
            <li class="nav-item">
                <a><i class="ft-folder"></i><span class="menu-title" data-i18n=""><?php echo app('translator')->get('site.roles'); ?></span></a>
                <ul class="menu-content">
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.roles.index')); ?>"><?php echo app('translator')->get('site.all'); ?>
                            <?php echo app('translator')->get('site.roles'); ?></a>
                    </li>
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.user.role.index')); ?>">
                            <?php echo app('translator')->get('site.users'); ?> <?php echo app('translator')->get('site.roles'); ?>
                        </a>
                    </li>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('read-notifications')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.notifications.index')); ?>"><i
                        class="fa fa-bullhorn"></i><span class="menu-title"
                        data-i18n=""><?php echo app('translator')->get('site.announcements'); ?></span></a>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('read-brands')): ?>
            <li class="nav-item"><a href="<?php echo e(route('dashboard.brands.index')); ?>"><i class="ft-bold"></i><span
                        class="menu-title" data-i18n=""><?php echo app('translator')->get('site.brands'); ?></span></a>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('read-categories')): ?>
            <li class="nav-item">
                <a><i class="ft-folder"></i><span class="menu-title" data-i18n=""><?php echo app('translator')->get('site.categories'); ?></span></a>
                <ul class="menu-content">
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.categories.index')); ?>"><?php echo app('translator')->get('site.all'); ?>
                            <?php echo app('translator')->get('site.categories'); ?></a>
                    </li>
                    <?php if(auth()->user()->can('create-categories')): ?>
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.categories.create')); ?>"><?php echo app('translator')->get('site.add'); ?>
                            <?php echo app('translator')->get('site.category'); ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

          
            <?php if(auth()->user()->can('read-products')): ?>
            <li class="nav-item">
                <a><i class="ft-folder"></i><span class="menu-title" data-i18n=""><?php echo app('translator')->get('site.products'); ?></span></a>
                <ul class="menu-content">
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.products.index')); ?>"><?php echo app('translator')->get('site.products'); ?></a>
                    </li>

                    <?php if(auth()->user()->can('create-products')): ?>
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.products.create')); ?>"><?php echo app('translator')->get('site.add'); ?>
                            <?php echo app('translator')->get('site.product'); ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <?php if(auth()->user()->can('read-stagnants')): ?>
            <li class="nav-item">
                <a><i class="ft-folder"></i><span class="menu-title" data-i18n=""><?php echo app('translator')->get('site.stagnants'); ?></span></a>
                <ul class="menu-content">
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.stagnants.index')); ?>"><?php echo app('translator')->get('site.all'); ?>
                            <?php echo app('translator')->get('site.stagnants'); ?></a>
                    </li>
                    <?php if(auth()->user()->can('create-stagnants')): ?>
                    <li>
                        <a class="menu-item" href="<?php echo e(route('dashboard.stagnants.create')); ?>"><?php echo app('translator')->get('site.add'); ?>
                            <?php echo app('translator')->get('site.stagnants'); ?></a>
                    </li>
                    <?php endif; ?>
                </ul>
            </li>
            <?php endif; ?>

            <li class="nav-item">
                <a><i class="ft-tag"></i><span class="menu-title" data-i18n="">Trademarks</span></a>
                <ul class="menu-content">
                    <li>
                        <a class="menu-item" href="trademarks.html">All Trademark</a>
                    </li>
                    <li>
                        <a class="menu-item" href="add-trademark.html">Add Trademark</a>
                    </li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                </ul>
            </li>

            <li class="nav-item">
                <a><i class="ft-shopping-cart"></i><span class="menu-title" data-i18n="">Products</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="products.html">All Product</a></li>
                    <li>
                        <a class="menu-item" href="add-product.html">Add Product</a>
                    </li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                </ul>
            </li>

            <li class="nav-item">
                <a><i class="fa fa-money"></i><span class="menu-title" data-i18n="">Offers prices</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="#">Soon</a></li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                </ul>
            </li>

            <li class="nav-item">
                <a><i class="ft-activity"></i><span class="menu-title" data-i18n="">Consulting</span></a>
                <ul class="menu-content">
                    <li><a class="menu-item" href="#">All Consulting</a></li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                    <li><a class="menu-item" href="#">Soon</a></li>
                </ul>
            </li>
        </ul>
    </div>
</div>
<!-- End / Sidebar-left-->
<?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/layouts/_aside.blade.php ENDPATH**/ ?>