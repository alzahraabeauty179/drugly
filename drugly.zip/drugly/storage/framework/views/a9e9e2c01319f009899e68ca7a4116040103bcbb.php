

<?php $__env->startSection('title', __('site.'.$module_name_plural)); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">

    <div class="container-fluid row d-flex justify-content-center">
        <?php if(session('success')): ?>
            <div class="alert alert-success col-sm-6 text-center" role="alert">
                <?php echo session('success'); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger col-sm-6 text-center" role="alert">
                <?php echo session('error'); ?>

            </div>
        <?php endif; ?>
    </div>
    
    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-1">
                <h3 class="content-header-title"><?php echo app('translator')->get('site.'.$module_name_plural ); ?></h3>
            </div>
            <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo app('translator')->get('site.home' ); ?></a>
                        </li>
                        <li class="breadcrumb-item active"><?php echo app('translator')->get('site.'.$module_name_plural ); ?></li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-body">
            <section id="configuration">
                <?php
                    $users = App\User::all();
                    $roles = App\Role::all();
                ?>
                <div class="row">
                    <div class="col-md-12 mb-1">
                        <button type="button" class="btn btn-info" data-toggle="modal" data-target="#add_user_role"><i
                                class="ft-plus"></i> <?php echo app('translator')->get('site.add'); ?> <?php echo app('translator')->get('site.'.$module_name_singular ); ?></button>
                        <?php echo $__env->make( 'dashboard.roles.users_roles.add_edit_modal' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"><?php echo app('translator')->get('site.'.$module_name_plural ); ?></h4>
                                <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                                <div class="heading-elements">
                                    <ul class="list-inline mb-0">
                                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                        <!-- <li><a data-action="close"><i class="ft-x"></i></a></li> -->
                                    </ul>
                                </div>
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <table class="table table-striped table-bordered zero-configuration" id="myUsersRolesTable">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th><?php echo app('translator')->get('site.name'); ?></th>
                                                <th><?php echo app('translator')->get('site.role'); ?></th>
                                                <th><?php echo app('translator')->get('site.created_at'); ?></th>
                                                <th><?php echo app('translator')->get('site.update'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td> <?php echo e(++$index); ?> </td>
                                                <td><?php echo e($row->user->name); ?></td>
                                                <td> 
                                                    <?php echo e($row->role->display_name); ?>

                                                </td>
                                                <td> <?php echo e(Carbon\Carbon::parse($row->created_at)->format('d M Y h:m')); ?> </td>
                                                <td>
                                                    <button type="button" class="btn btn-info btn-sm" data-toggle="modal" data-target="#edit_user_role_<?php echo e($row->user_id.$row->role_id); ?>">
                                                        <i class="fa fa-cog fa-fw"></i> <?php echo app('translator')->get('site.update'); ?>
                                                    </button>
                                                    <?php echo $__env->make( 'dashboard.roles.users_roles.add_edit_modal' , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr><td colspan="4" style="text-align: center;"><h4><?php echo app('translator')->get('site.no_records'); ?></h4></td></tr>
                                        <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th><?php echo app('translator')->get('site.name'); ?></th>
                                                <th><?php echo app('translator')->get('site.role'); ?></th>
                                                <th><?php echo app('translator')->get('site.created_at'); ?></th>
                                                <th><?php echo app('translator')->get('site.update'); ?></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--/ Zero configuration table -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>


<!-- Bootstrap CSS -->
<!-- <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"> -->
<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">


<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" 
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" 
            crossorigin="anonymous">
    </script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready( function () {
            $('#myUsersRolesTable').DataTable();
        } );
    </script>

    <?php if( Session::has('createUserRoleError') ): ?>
        <script>
            $(document).ready(function(){
                $('#edit_profile').modal({show: true});
            });
        </script>
    <?php endif; ?>

    <?php if( Session::has('updateUserRoleError') ): ?>
        <script>
            $(document).ready(function(){
                $('#edit_user_role_<?php echo e(session("id")); ?>').modal({show: true});
            });
        </script>
    <?php endif; ?>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/roles/users_roles/index.blade.php ENDPATH**/ ?>