<?php if(auth()->user()->can('delete-'.$module_name_plural)): ?>
<form action="<?php echo e(route('dashboard.'.$module_name_plural.'.destroy', $row)); ?>" method="POST" style="display: inline-block">
    <?php echo e(csrf_field()); ?>

    <?php echo e(method_field('DELETE')); ?>


    <button type="submit" title="<?php echo app('translator')->get('site.delete'); ?>" class="btn btn-danger btn-sm" data-original-title="<?php echo app('translator')->get('site.delete'); ?>">
        <i class="fa fa-times"> <?php echo app('translator')->get('site.delete'); ?></i>
    </button> 
</form>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/buttons/delete.blade.php ENDPATH**/ ?>