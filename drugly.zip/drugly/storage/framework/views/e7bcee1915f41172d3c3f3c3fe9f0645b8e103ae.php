<!-- Modal Edit Profile -->

<div class="modal fade" id="edit_profile" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

        <div class="modal-content">

            <div class="card">

                <div class="card-header">
                    <h4 class="card-title"><?php echo app('translator')->get('site.update_profile_info'); ?></h4>
                    <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a class="close" data-dismiss="modal" aria-label="Close"><i class="ft-x"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="card-content collpase show">
                    <div class="card-body">
                        <div class="card-text">
                            <p class="card-text"><?php echo app('translator')->get('site.update_profile_hint'); ?></p>
                        </div>

                        
                        <div class="container-fluid row d-flex justify-content-center ">
                            <?php if( Session::has('updateProfileErrorMessage') ): ?>
                                <div class="alert col-sm-6 text-center alert-<?php echo e(session('message_type') == 'success' ?  'success'  :  'warning'); ?>"
                                        role="alert">
                                    <?php echo e(session('updateProfileErrorMessage')); ?>

                                </div>
                            <?php endif; ?>
                        </div><!-- end alert -->

                        <form   class="form" method="POST" enctype="multipart/form-data" 
                                action="<?php echo e(route('dashboard.users.update', ['user' => $row->id])); ?>"
                        >
                            <?php echo method_field('PUT'); ?>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-body">
                                <h4 class="form-section"><i class="ft-user"></i> <?php echo app('translator')->get('site.personal_information'); ?> </h4>
                                <div class="row">
                                    <div class="col-md-12">
                                        <div class="form-group">
                                            <label for="projectinput1" class="sr-only"> <?php echo app('translator')->get('site.full_name'); ?> </label>
                                            <input  type="text" id="projectinput1" class="form-control <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    value="<?php echo e(auth()->user()->name); ?>" placeholder="<?php echo app('translator')->get('site.full_name'); ?>" name="name">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput3" class="sr-only"> <?php echo app('translator')->get('site.email'); ?> </label>
                                            <input  type="email" id="projectinput3" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    value="<?php echo e(auth()->user()->email); ?>" placeholder="<?php echo app('translator')->get('site.email'); ?>" name="email">
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput4" class="sr-only"> <?php echo app('translator')->get('site.contact_number'); ?> </label>
                                            <input  type="text" id="projectinput4" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    value="<?php echo e(auth()->user()->phone); ?>" placeholder="<?php echo app('translator')->get('site.phone'); ?>" name="phone">
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <fieldset class="form-group col-md-12">
                                        <label for="basicInputFile"> <?php echo app('translator')->get('site.upload_photo'); ?> </label>
                                        <div class="custom-file">
                                            <input type="file" class="custom-file-input" id="profile_image" name="image">
                                            <label class="custom-file-label" for="profile_image"> <?php echo app('translator')->get('site.choose_file'); ?> </label>
                                        </div>
                                    </fieldset>
                                </div>

                                <h4 class="form-section"><i class="ft-lock"></i> <?php echo app('translator')->get('site.change_password'); ?> </h4>

                                <div class="form-group">
                                    <label for="current_password" class="sr-only"> <?php echo app('translator')->get('site.current_password'); ?> </label>
                                    <input  type="password" id="current_password" class="form-control <?php $__errorArgs = ['current_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            placeholder="<?php echo app('translator')->get('site.current_password'); ?>" name="current_password">
                                </div>

                                <div class="form-group">
                                    <label for="new_password" class="sr-only"><?php echo app('translator')->get('site.new_password'); ?></label>
                                    <input  type="password" id="new_password" class="form-control <?php $__errorArgs = ['new_password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            placeholder="<?php echo app('translator')->get('site.new_password'); ?>" name="new_password">
                                </div>

                                <div class="form-group">
                                    <label for="new_password_confirmation" class="sr-only"><?php echo app('translator')->get('site.new_password_confirmation'); ?></label>
                                    <input  type="password" id="new_password_confirmation" class="form-control <?php $__errorArgs = ['new_password_confirmation'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                            placeholder="<?php echo app('translator')->get('site.new_password_confirmation'); ?>" name="new_password_confirmation">
                                </div>
                            </div>

                            <div class="form-actions">
                                <button type="button" class="btn btn-outline-warning mr-1" data-dismiss="modal">
                                    <i class="ft-x"></i> <?php echo app('translator')->get('site.cancel'); ?>
                                </button>
                                <button type="submit" class="btn btn-outline-primary">
                                    <i class="ft-check"></i> <?php echo app('translator')->get('site.save'); ?>
                                </button>
                            </div>
                        </form>
                    </div>
                </div>
            </div> 

        </div>

    </div>
</div>

<!-- ./End Modal Edit Profile -->

<!-- Modal Edit Info -->

<div class="modal fade" id="edit_info" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    
    <div class="modal-dialog" role="document">

        <div class="modal-content" style="width: 140%;">

            <div class="card">

                <div class="card-header">
                    <h4 class="card-title"><?php echo app('translator')->get('site.update_site_information'); ?></h4>
                    <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a class="close" data-dismiss="modal" aria-label="Close"><i class="ft-x"></i></a></li>
                        </ul>
                    </div>
                </div> <!-- end card-header -->

                <div class="card-content collpase show">

                    <div class="card-body">

                        <div class="card-text">
                            <p class="card-text"><?php echo app('translator')->get('site.update_site_information_hint'); ?></p>
                        </div><!-- end card-text -->

                        <div class="container-fluid row d-flex justify-content-center" style="margin-top: 20px;">
                            <?php if( Session::has('updateWebsiteErrorMessage') ): ?>
                                <div class="alert col-sm-6 text-center alert-<?php echo e(session('message_type') == 'success' ?  'success'  :  'warning'); ?>"
                                        role="alert">
                                    <?php echo e(session('updateWebsiteErrorMessage')); ?>

                                </div>
                            <?php endif; ?>
                        </div><!-- end alert -->

                        <form   class="form" method="POST" enctype="multipart/form-data" 
                                <?php if( is_null($app_settings) ): ?>
                                    <?php if( auth()->user()->type == "super_admin" ): ?>
                                        action="<?php echo e(route('dashboard.appsettings.store')); ?>"
                                    <?php else: ?>
                                        action="<?php echo e(route('dashboard.stores.store')); ?>"
                                    <?php endif; ?>
                                <?php else: ?>
                                    <?php if( auth()->user()->type == "super_admin" ): ?>
                                        action="<?php echo e(route('dashboard.appsettings.update', [ 'appsetting' => $app_settings->id ])); ?>"
                                    <?php else: ?>
                                        action="<?php echo e(route('dashboard.stores.update', [ 'store' => $app_settings->id ])); ?>"
                                    <?php endif; ?>
                                <?php endif; ?>
                        >
                        
                            <?php if( is_null($app_settings) ): ?>
                                <?php echo method_field('POST'); ?>
                            <?php else: ?>
                                <?php echo method_field('PUT'); ?>
                            <?php endif; ?>
                            
                            <?php echo e(csrf_field()); ?>


                            <div class="form-body">

                                <h4 class="form-section"><i class="ft-user"></i> <?php echo app('translator')->get('site.contact_information'); ?> </h4>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput3" class="sr-only"><?php echo app('translator')->get('site.email'); ?></label>
                                            <input  type="email" id="projectinput3" class="form-control <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    placeholder="<?php echo app('translator')->get('site.email'); ?>" name="email" value="<?php echo e(!is_null($app_settings) ? $app_settings->email : old('email')); ?>">
                                        </div>
                                    </div><!-- end email col-md-6 -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput4" class="sr-only"><?php echo app('translator')->get('site.contact_number'); ?></label>
                                            <input  type="text" id="projectinput4" class="form-control <?php $__errorArgs = ['phone'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    placeholder="<?php echo app('translator')->get('site.phone'); ?>" name="phone" value="<?php echo e(!is_null($app_settings) ? $app_settings->phone : old('phone')); ?>">
                                        </div>
                                    </div><!-- end phone col-md-6 -->
                                </div><!-- end contact_information row -->

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput1" class="sr-only"> <?php echo app('translator')->get('site.facebook_link'); ?> </label>
                                            <input  type="text" id="projectinput1" class="form-control <?php $__errorArgs = ['facebook_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    placeholder="<?php echo app('translator')->get('site.facebook_link'); ?>" name="facebook_link" value="<?php echo e(!is_null($app_settings) ? $app_settings->facebook_link : old('facebook_link')); ?>">
                                        </div>
                                    </div><!-- end facebook_link col-md-6 -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput2" class="sr-only"> <?php echo app('translator')->get('site.twitter_link'); ?> </label>
                                            <input   type="text" id="projectinput2" class="form-control  <?php $__errorArgs = ['twitter_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    placeholder="<?php echo app('translator')->get('site.twitter_link'); ?>" name="twitter_link" value="<?php echo e(!is_null($app_settings) ? $app_settings->twitter_link : old('twitter_link')); ?>">
                                        </div>
                                    </div><!-- end twitter_link col-md-6 -->
                                </div><!-- end links row 1 -->

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput1" class="sr-only"> <?php echo app('translator')->get('site.instagram_link'); ?> </label>
                                            <input  type="text" id="projectinput1" class="form-control <?php $__errorArgs = ['instagram_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    placeholder="<?php echo app('translator')->get('site.instagram_link'); ?>" name="instagram_link" value="<?php echo e(!is_null($app_settings) ? $app_settings->instagram_link : old('instagram_link')); ?>">
                                        </div>
                                    </div><!-- end instagram_link col-md-6 -->
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="projectinput2" class="sr-only"> <?php echo app('translator')->get('site.youtube_link'); ?> </label>
                                            <input  type="text" id="projectinput2" class="form-control <?php $__errorArgs = ['youtube_link'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                    placeholder="<?php echo app('translator')->get('site.youtube_link'); ?>" name="youtube_link" value="<?php echo e(!is_null($app_settings) ? $app_settings->youtube_link : old('youtube_link')); ?>">
                                        </div>
                                    </div><!-- end youtube_link col-md-6 -->
                                </div><!-- end links row 2 -->

                                <h4 class="form-section"><i class="ft-check-circle"></i> <?php echo app('translator')->get('site.requirements'); ?></h4>

                                <div class="row">
                                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <label for="<?php echo e($locale); ?>[name]">
                                                    <?php if( auth()->user()->type == 'super_admin' ): ?>
                                                        <?php echo app('translator')->get('site.website'); ?>
                                                    <?php else: ?>
                                                        <?php echo app('translator')->get('site.' . auth()->user()->type); ?> 
                                                    <?php endif; ?>
                                                    <?php echo app('translator')->get('site.' . $locale . '.name'); ?>
                                                </label>
                                                <input  type="text" id="<?php echo e($locale); ?>[name]" class="form-control <?php $__errorArgs = [$locale . ' .name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                        value="<?php echo e(!is_null($app_settings) ? $app_settings->translate($locale)->name : old($locale . '.name')); ?>"
                                                        placeholder="<?php echo app('translator')->get('site.' . auth()->user()->type); ?> <?php echo app('translator')->get('site.' . $locale . '.name'); ?>" name="<?php echo e($locale); ?>[name]">
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-md-12">
                                        <fieldset class="form-group">
                                            <label for="basicInputFile"> <?php echo app('translator')->get('site.logo'); ?> </label>
                                            <div class="custom-file">
                                                <input type="file" class="custom-file-input" id="store_logo" name="logo">
                                                <label class="custom-file-label" for="store_logo"> <?php echo app('translator')->get('site.choose_file'); ?> </label>
                                            </div>
                                        </fieldset>
                                    </div> <!-- end logo col-md-12 -->
                                <!-- end name & logo row -->

                                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="<?php echo e($locale); ?>[description]"> <?php echo app('translator')->get('site.' . $locale . '.description'); ?></label>
                                                <textarea   id="<?php echo e($locale); ?>[description]" rows="5" class="form-control <?php $__errorArgs = [$locale . ' .description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                            name="<?php echo e($locale); ?>[description]" 
                                                            placeholder="<?php echo app('translator')->get('site.' . auth()->user()->type); ?> <?php echo app('translator')->get('site.' . $locale . '.description'); ?>" >
                                                    <?php if( !is_null($app_settings) ): ?> <?php echo $app_settings->translate($locale)->description; ?> <?php endif; ?>
                                                </textarea>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- end description col-md-12 -->

                                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="<?php echo e($locale); ?>[about_us]"> <?php echo app('translator')->get('site.' . $locale . '.about_us'); ?> </label>
                                                <textarea   id="<?php echo e($locale); ?>[about_us]" rows="5" class="form-control <?php $__errorArgs = [$locale . ' .about_us'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                            name="<?php echo e($locale); ?>[about_us]" 
                                                            placeholder="<?php echo app('translator')->get('site.' . auth()->user()->type); ?> <?php echo app('translator')->get('site.' . $locale . '.about_us'); ?>" >
                                                    <?php if( !is_null($app_settings) ): ?> <?php echo $app_settings->translate($locale)->about_us; ?> <?php endif; ?>
                                                </textarea>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- end about_us col-md-12 -->

                                    <?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="col-md-12">
                                            <div class="form-group">
                                                <label for="<?php echo e($locale); ?>[privacy_policy]"> <?php echo app('translator')->get('site.' . $locale . '.privacy_policy'); ?></label>
                                                <textarea   id="<?php echo e($locale); ?>[privacy_policy]" rows="5" class="form-control <?php $__errorArgs = [$locale . ' .privacy_policy'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
                                                            name="<?php echo e($locale); ?>[privacy_policy]" 
                                                            placeholder="<?php echo app('translator')->get('site.' . auth()->user()->type); ?> <?php echo app('translator')->get('site.' . $locale . '.privacy_policy'); ?>" >
                                                    <?php if( !is_null($app_settings) ): ?> <?php echo $app_settings->translate($locale)->privacy_policy; ?> <?php endif; ?>
                                                </textarea>
                                            </div>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <!-- end privacy_policy col-md-12 -->
                                </div><!-- end description and about_us and privacy_policy row -->

                            </div></div><!-- بلا هدف two /divs -->

                            </div><!-- end form-body -->

                            <div class="form-actions">
                                <button type="button" class="btn btn-outline-warning mr-1" data-dismiss="modal">
                                    <i class="ft-x"></i> <?php echo app('translator')->get('site.cancel'); ?>
                                </button>
                                <button type="submit" class="btn btn-outline-primary">
                                    <i class="ft-check"></i> <?php echo app('translator')->get('site.save'); ?>
                                </button>
                            </div><!-- end form-actions -->

                        </form><!-- end form -->

                    </div><!-- end card-body -->

                </div><!-- end card-content -->

            </div><!-- end card -->

        </div><!-- end modal-content -->

    </div><!-- end modal-dialog -->

</div><!-- end modal fade -->

<!-- ./End Modal Edit Info --><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/users/modals.blade.php ENDPATH**/ ?>