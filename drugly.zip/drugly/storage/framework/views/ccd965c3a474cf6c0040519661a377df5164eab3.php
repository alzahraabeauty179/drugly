

<?php $__env->startSection('title', __('site.'.$module_name_plural)); ?>

<?php $__env->startSection('content'); ?>
    <div class="app-content content">
        <div class="container-fluid row d-flex justify-content-center">
            <?php if(session('success')): ?>
                <div class="alert alert-success col-sm-6 text-center" role="alert">
                    <?php echo session('success'); ?>

                </div>
            <?php endif; ?>

            <?php if(session('error')): ?>
                <div class="alert alert-danger col-sm-6 text-center" role="alert">
                    <?php echo session('error'); ?>

                </div>
            <?php endif; ?>
        </div>
        <div class="content-wrapper">
            <div class="content-header row">
                <div class="content-header-left col-md-6 col-12 mb-1">
                    <h3 class="content-header-title"><?php echo app('translator')->get('site.'.$module_name_plural); ?></h3>
                </div>
                <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
                    <div class="breadcrumb-wrapper col-12">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo app('translator')->get('site.home'); ?></a>
                            </li>
                            <li class="breadcrumb-item active"><?php echo app('translator')->get('site.'.$module_name_plural); ?></li>
                        </ol>
                    </div>
                </div>
            </div>
            <div class="content-body">
                <section id="configuration">
                    <div class="row">
                        <div class="col-md-12 mb-1">
                            <a class="btn btn-info" href="<?php echo e(route('dashboard.'.$module_name_plural.'.create')); ?>"><i class="ft-plus"></i> <?php echo app('translator')->get('site.add'); ?> <?php echo app('translator')->get('site.'.$module_name_singular); ?> </a>
                        </div>
                        <div class="col-12">
                            <div class="card">
                                <div class="card-header">
                                    <h4 class="card-title"><?php echo app('translator')->get('site.'.$module_name_plural); ?></h4>
                                    <a class="heading-elements-toggle"><i
                                            class="fa fa-ellipsis-v font-medium-3"></i></a>
                                    <div class="heading-elements">
                                        <ul class="list-inline mb-0">
                                            <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                            <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                            <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                            <!-- <li><a data-action="close"><i class="ft-x"></i></a></li> -->
                                        </ul>
                                    </div>
                                </div>
                                <div class="card-content collapse show">
                                    <div class="card-body card-dashboard">
                                        <?php if($rows->count() > 0): ?>
                                            <table class="table table-striped table-bordered zero-configuration">
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th><?php echo app('translator')->get('site.'.$module_name_singular); ?></th>
                                                        <th><?php echo app('translator')->get('site.category'); ?></th>
                                                        <?php if( auth()->user()->isAbleTo('edit_category') ): ?>
                                                            <th><?php echo app('translator')->get('site.edit'); ?></th>
                                                        <?php endif; ?>
                                                        <?php if( auth()->user()->isAbleTo('delete_category') ): ?>
                                                            <th><?php echo app('translator')->get('site.delete'); ?></th>
                                                        <?php endif; ?>
                                                        <th><?php echo app('translator')->get('site.logo'); ?></th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <tr>
                                                        <td> <?php echo e(++$index); ?> </td>
                                                        <td> <?php echo e($row->name); ?> </td>
                                                        <td> <?php echo e($row->parent->name); ?> </td>
                                                        <?php if( auth()->user()->isAbleTo('edit_category') ): ?>
                                                            <td> <?php echo $__env->make('dashboard.buttons.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </td>
                                                        <?php endif; ?>
                                                        <?php if( auth()->user()->isAbleTo('delete_category') ): ?>
                                                            <td> <?php echo $__env->make('dashboard.buttons.delete', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?> </td>
                                                        <?php endif; ?>
                                                        <td>
                                                            <figure class="col-md-3 col-sm-6 col-12" itemprop="associatedMedia" itemscope itemtype="http://schema.org/ImageObject">
                                                                <a href="<?php echo e(asset($row->image_path)); ?>" itemprop="contentUrl">
                                                                    <img class="img-thumbnail img-fluid" src="<?php echo e(asset($row->image_path)); ?>" itemprop="thumbnail" alt="<?php echo e($row->description); ?>" />
                                                                </a>
                                                            </figure>
                                                        </td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </tbody>
                                                <tfoot>
                                                    <tr>
                                                        <th>#</th>
                                                        <th><?php echo app('translator')->get('site.'.$module_name_singular); ?></th>
                                                        <th><?php echo app('translator')->get('site.category'); ?></th>
                                                        <?php if( auth()->user()->isAbleTo('edit_category') ): ?>
                                                            <th><?php echo app('translator')->get('site.edit'); ?></th>
                                                        <?php endif; ?>
                                                        <?php if( auth()->user()->isAbleTo('delete_category') ): ?>
                                                            <th><?php echo app('translator')->get('site.delete'); ?></th>
                                                        <?php endif; ?>
                                                        <th><?php echo app('translator')->get('site.logo'); ?></th>
                                                    </tr>
                                                </tfoot>
                                            </table>

                                        <?php else: ?>
                                            <h4><?php echo app('translator')->get('site.no_records'); ?></h4>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
                <!--/ Zero configuration table -->
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/subcategories/index.blade.php ENDPATH**/ ?>