<?php echo e(csrf_field()); ?>


<?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group col-md-6 mb-2">
        <div class="form-group">
            <label class="bmd-label-floating"><?php echo app('translator')->get('site.' . $locale . '.title'); ?></label>
            <input type="text" class="form-control <?php $__errorArgs = [$locale . ' .title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name=" <?php echo e($locale); ?>[title]"
                value="<?php echo e(isset($row) ? $row->translate($locale)->title : old($locale . '.title')); ?>">

            <?php $__errorArgs = [$locale . '.title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class=" text text-danger" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group col-md-6 mb-2">
        <div class="form-group">
            <label class="bmd-label-floating"><?php echo app('translator')->get('site.' . $locale . '.content'); ?></label>
            <textarea name=" <?php echo e($locale); ?>[content]" id="" cols="30" rows="10" class="form-control <?php $__errorArgs = [$locale . ' .content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(isset($row) ? $row->translate($locale)->content : old($locale . '.content')); ?></textarea>

            <?php $__errorArgs = [$locale . '.content'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                <small class=" text text-danger" role="alert">
                    <strong><?php echo e($message); ?></strong>
                </small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="form-group col-md-6">
    <div class="text-bold-600 font-medium-2">
        <?php echo app('translator')->get('site.all_users'); ?>
    </div>
    <div class="form-group pb-1">
        <div class="float-right">
        <input type="checkbox" name="all_users" id="switchery0" class="switchery" <?php $__errorArgs = ['users_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php else: ?> checked <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> />
        </div>
        <label for="switchery0" class="font-medium-2 text-bold-600"><?php echo app('translator')->get('site.send_to_all_users'); ?></label>
        
        <?php $__errorArgs = ['users_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<div class="form-group col-md-6" id="custom-users" style=" <?php $__errorArgs = ['users_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <?php else: ?> display:none <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
    <div class="text-bold-600 font-medium-2">
        <?php echo app('translator')->get('site.custom_users'); ?>
    </div>
    <select class="select2 form-control <?php $__errorArgs = ['users_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            id="users_id" name="users_id[]" multiple="multiple"
    >
        <optgroup label="<?php echo app('translator')->get('site.medical_store'); ?>">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($user->type == "medical_store"): ?>
                <option value="<?php echo e($user->id); ?>" 
                    <?php echo e(isset($row) && $row->id == $user->id  ? 'selected' : ''); ?> >
                    <?php echo e($user->name); ?>

                </option>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <optgroup label="<?php echo app('translator')->get('site.no_medical_stores'); ?>">
                </optgroup>
            <?php endif; ?>
        </optgroup>

        <optgroup label="<?php echo app('translator')->get('site.beauty_company'); ?>">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($user->type == "beauty_company"): ?>
                <option value="<?php echo e($user->id); ?>" 
                    <?php echo e(isset($row) && $row->id == $user->id  ? 'selected' : ''); ?> >
                    <?php echo e($user->name); ?>

                </option>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <optgroup label="<?php echo app('translator')->get('site.no_beauty_companies'); ?>">
                </optgroup>
            <?php endif; ?>
        </optgroup>

        <optgroup label="<?php echo app('translator')->get('site.pharmacy'); ?>">
            <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <?php if($user->type == "pharmacy"): ?>
                <option value="<?php echo e($user->id); ?>" 
                    <?php echo e(isset($row) && $row->id == $user->id  ? 'selected' : ''); ?> >
                    <?php echo e($user->name); ?>

                </option>
                <?php endif; ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <optgroup label="<?php echo app('translator')->get('site.no_beauty_pharmacies'); ?>">
                </optgroup>
            <?php endif; ?>
        </optgroup>
    </select>
</div>

<?php $__env->startPush('script'); ?>
    <script>
        $(document).ready( function () {
            $('#switchery0').click(function() {
                if( $('#custom-users').css('display') == 'none' )
                    $('#custom-users').removeAttr('style');
                else
                    $('#custom-users').css('display', 'none')
            });
        });
    </script>
<?php $__env->stopPush(); ?><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/notifications/form.blade.php ENDPATH**/ ?>