<a href="javascript:void(0)">
    <div class="media">
        <div class="media-left align-self-center">
            <i class="ft-shield icon-bg-circle bg-cyan"></i>
        </div>
        <div class="media-body">
            <h6 class="media-heading"><?php echo app('translator')->get('site.app_manager'); ?></h6>
            <p class="notification-text font-small-3 text-muted">
                <?php if( empty($noti->data['message'][App::getLocale()]) ): ?>
                    <?php echo app('translator')->get('site.' . $noti->data['message']); ?>
                <?php else: ?>
                    <?php echo e($noti->data['message'][App::getLocale()]); ?>

                <?php endif; ?>
            </p>
            <small>
                
                <time class="media-meta text-muted" datetime="<?php echo e($noti->data['sendAt']); ?>">
                    <?php echo e(Carbon\Carbon::parse($noti->data['sendAt'])->diffForHumans()); ?>

                </time>
            </small>
        </div>
    </div> 
</a><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/notification/navbar/announcement.blade.php ENDPATH**/ ?>