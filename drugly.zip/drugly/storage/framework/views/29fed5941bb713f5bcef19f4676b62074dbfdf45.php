<?php if(session('success')): ?>

<script>
    new Noty({
            type: 'success',
            layout: 'topRight',
            text: "<?php echo e(session('success')); ?>",
            timeout: 2000,
            killer: true
        }).show();
</script>

<?php elseif( session('error') ): ?>
<script>
    new Noty({
        type: 'error',
        layout: 'topRight',
        text: "<?php echo e(session('error')); ?>",
        timeout: 2000,
        killer: true
    }).show();
</script>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/partials/_session.blade.php ENDPATH**/ ?>