<!-- Modal Users Roles -->

<div    class="modal fade" id="<?php echo e(isset($row) ? 'edit_user_role_'.$row->user_id.$row->role_id : 'add_user_role'); ?>" 
        tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">

        <div class="modal-content">

            <div class="card">
                <div class="card-header">
                    <h4 class="card-title"><?php echo app('translator')->get('site.'.$module_name_singular ); ?></h4>
                    <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                    <div class="heading-elements">
                        <ul class="list-inline mb-0">
                            <li><a class="close" data-dismiss="modal" aria-label="Close"><i class="ft-x"></i></a></li>
                        </ul>
                    </div>
                </div>

                <div class="card-content collpase show">
                    <div class="card-body">
                        

                        <div class="container-fluid row d-flex justify-content-center ">
                            <?php if( Session::has('createUserRoleError') ): ?>
                                <div class="alert col-sm-6 text-center alert-<?php echo e(session('message_type') == 'success' ?  'success'  :  'warning'); ?>"
                                        role="alert">
                                    <?php echo e(session('createUserRoleError')); ?>

                                </div>
                            <?php elseif( isset($row) && Session::has('updateUserRoleError') && session("id") == $row->user_id.$row->role_id): ?>
                                <div class="alert col-sm-6 text-center alert-<?php echo e(session('message_type') == 'success' ?  'success'  :  'warning'); ?>"
                                        role="alert">
                                    <?php echo e(session('createUserRoleError')); ?>

                                </div>
                            <?php endif; ?>
                        </div><!-- end alert -->

                        <form   class="form" method="POST" enctype="multipart/form-data" id="<?php echo e(isset($row) ? 'edit_user_role_form_'.$row->user_id.$row->role_id : 'add_user_role_form'); ?>"
                                action="<?php echo e(route('dashboard.user.role.createUpdate')); ?>"
                        >
                            <?php echo method_field('POST'); ?>
                            <?php echo e(csrf_field()); ?>

                            <div class="form-body">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="text-bold-600 font-medium-2">
                                                <?php echo app('translator')->get('site.users'); ?>
                                            </div>
                                            <select class="select2 form-control" id="user_id" name="user_id">
                                                <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($user->id); ?>" <?php echo e(isset($row) && $row->user_id == $user->id  ? 'selected' : ''); ?>>
                                                    <?php echo e($user->name.' - '.__('site.' . $user->type)); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>

                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <div class="text-bold-600 font-medium-2">
                                                <?php echo app('translator')->get('site.roles'); ?>
                                            </div>
                                            <select class="select2 form-control" id="role_id" name="role_id">
                                                <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($role->id); ?>" <?php echo e(isset($row) && $row->role_id == $role->id  ? 'selected' : ''); ?>>
                                                    <?php echo e($role->display_name); ?>

                                                </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div> 

            <div class="modal-footer" style="border-top: none;">
                <div class="form-actions">
                    <button type="button" class="btn btn-outline-warning mr-1" data-dismiss="modal">
                        <i class="ft-x"></i> <?php echo app('translator')->get('site.cancel'); ?>
                    </button>
                    <button type="submit" form="<?php echo e(isset($row) ? 'edit_user_role_form_'.$row->user_id.$row->role_id : 'add_user_role_form'); ?>" 
                            class="btn btn-outline-primary">
                        <i class="ft-check"></i> <?php echo app('translator')->get('site.save'); ?>
                    </button>
                </div>
            </div>

        </div>

    </div>
</div>

<!-- ./End Modal Users Roles --><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/roles/users_roles/add_edit_modal.blade.php ENDPATH**/ ?>