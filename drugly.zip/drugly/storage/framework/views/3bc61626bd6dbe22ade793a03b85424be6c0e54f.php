

<?php $__env->startSection('title', __('site.announcements')); ?>

<?php $__env->startSection('content'); ?>
<div class="app-content content">
    <div class="container-fluid row d-flex justify-content-center">
        <?php if(session('success')): ?>
            <div class="alert alert-success col-sm-6 text-center" role="alert">
                <?php echo session('success'); ?>

            </div>
        <?php endif; ?>

        <?php if(session('error')): ?>
            <div class="alert alert-danger col-sm-6 text-center" role="alert">
                <?php echo session('error'); ?>

            </div>
        <?php endif; ?>
    </div>

    <div class="content-wrapper">
        <div class="content-header row">
            <div class="content-header-left col-md-6 col-12 mb-1">
                <h3 class="content-header-title"><?php echo app('translator')->get('site.announcements'); ?></h3>
            </div>
            <div class="content-header-right breadcrumbs-right breadcrumbs-top col-md-6 col-12">
                <div class="breadcrumb-wrapper col-12">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="<?php echo e(route('dashboard.home')); ?>"><?php echo app('translator')->get('site.home' ); ?></a>
                        </li>
                        <li class="breadcrumb-item active"><?php echo app('translator')->get('site.announcements'); ?></li>
                    </ol>
                </div>
            </div>
        </div>
        <div class="content-body">
            <section id="configuration">
                <div class="row">
                    <div class="col-md-12 mb-1">
                        <a class="btn btn-info" href="<?php echo e(route('dashboard.'.$module_name_plural.'.create')); ?>"><i
                            class="ft-plus"></i> <?php echo app('translator')->get('site.add'); ?> <?php echo app('translator')->get('site.announcement' ); ?></a>
                    </div>
                    <div class="col-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title"><?php echo app('translator')->get('site.announcement' ); ?></h4>
                                <a class="heading-elements-toggle"><i class="fa fa-ellipsis-v font-medium-3"></i></a>
                                <div class="heading-elements">
                                    <ul class="list-inline mb-0">
                                        <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                                        <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                                        <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                                        <!-- <li><a data-action="close"><i class="ft-x"></i></a></li> -->
                                    </ul>
                                </div>
                            </div>
                            <div class="card-content collapse show">
                                <div class="card-body card-dashboard">
                                    <?php $local = App::getLocale(); ?>
                                    <table class="table table-striped table-bordered zero-configuration" id="myAnnouncesTable">
                                        <thead>
                                            <tr>
                                                <th>#</th>
                                                <th><?php echo app('translator')->get('site.title'); ?></th>
                                                <th><?php echo app('translator')->get('site.content'); ?></th>
                                                <th><?php echo app('translator')->get('site.send_date'); ?></th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__empty_1 = true; $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index=>$noti): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                            <tr>
                                                <td> <?php echo e(++$index); ?> </td>
                                                <td> 
                                                    <?php if(gettype($noti->data) == 'string'): ?>
                                                        <?php echo e(json_decode($noti->data)->title->$local); ?>

                                                    <?php else: ?>
                                                        <?php echo e($noti->data['title'][App::getLocale()]); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td> 
                                                    <?php echo $__env->make( 'dashboard.users.notis.' . \Illuminate\Support\Str::snake( class_basename($noti->type, '_') ) , \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                                                </td>
                                                <td> <?php echo e(Carbon\Carbon::parse(json_decode($noti->data)->sendAt)->format('d M Y h:m')); ?> </td>
                                            </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr><td colspan="4" style="text-align: center;"><h4><?php echo app('translator')->get('site.no_records'); ?></h4></td></tr>
                                        <?php endif; ?>
                                        </tbody>
                                        <tfoot>
                                            <tr>
                                                <th>#</th>
                                                <th><?php echo app('translator')->get('site.title'); ?></th>
                                                <th><?php echo app('translator')->get('site.content'); ?></th>
                                                <th><?php echo app('translator')->get('site.send_date'); ?></th>
                                            </tr>
                                        </tfoot>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>
            <!--/ Zero configuration table -->
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('style'); ?>


<!-- Bootstrap CSS -->
<!-- <link href="//netdna.bootstrapcdn.com/bootstrap/3.2.0/css/bootstrap.min.css" rel="stylesheet"> -->
<link rel="stylesheet" href="//cdn.datatables.net/1.10.7/css/jquery.dataTables.min.css">
<link rel="stylesheet" href="https://cdn.datatables.net/1.10.25/css/jquery.dataTables.min.css">


<?php $__env->stopPush(); ?>

<?php $__env->startPush('script'); ?>
    
    <!-- jQuery -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js" 
            integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" 
            crossorigin="anonymous">
    </script>
    <!-- DataTables -->
    <script src="https://cdn.datatables.net/1.10.25/js/jquery.dataTables.min.js"></script>

    <script>
        $(document).ready( function () {
            $('#myAnnouncesTable').DataTable();
        } );
    </script>
<?php $__env->stopPush(); ?>
<?php echo $__env->make('dashboard.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/notifications/index.blade.php ENDPATH**/ ?>