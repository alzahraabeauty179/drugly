<?php echo e(csrf_field()); ?>



<div class="form-group col-md-6 mb-2">
    <div class="form-group">
        <label class="bmd-label-floating"><?php echo app('translator')->get('site.name'); ?></label>
        <input name="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($row) ? $row->name : old('name')); ?>">
        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>


<div class="form-group col-md-6 mb-2">
    <div class="form-group">
        <label class="bmd-label-floating"><?php echo app('translator')->get('site.description'); ?></label>
        <input name="description" class="form-control <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" value="<?php echo e(isset($row) ? $row->description : old('description')); ?>">
        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <small class=" text text-danger" role="alert">
            <strong><?php echo e($message); ?></strong>
        </small>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>
</div>

<?php
$models = config('laratrust_seeder.role_structure.super');
// dd($models);
$maps = ['create', 'read', 'update', 'delete'];
?>


    <?php $__currentLoopData = $models; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $model => $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="list-group col-md-3 mb-2">
        <div class="form-group">
        <a href="#" class="list-group-item active">
            <?php echo app('translator')->get('site.'.$model); ?>
        </a>
        <?php $__currentLoopData = $maps; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $map): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label><?php echo app('translator')->get('site.'.$map); ?></label>
        <input type="checkbox" style="height: 20px" class="form-control" name="permissions[]"
                <?php echo e(isset($row) && $row->hasPermission($map . '-' . $model) ? 'checked' : ''); ?>

                value="<?php echo e($map . '-' . $model); ?>">
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <div class="col-md-12"></div>
<?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/roles/form.blade.php ENDPATH**/ ?>