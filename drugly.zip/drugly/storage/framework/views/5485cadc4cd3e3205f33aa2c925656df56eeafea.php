<?php echo e(csrf_field()); ?>


<?php $__currentLoopData = config('translatable.locales'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $locale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="form-group col-md-6 mb-2">
        <div class="form-group">
            <label class="bmd-label-floating"><?php echo app('translator')->get('site.' . $locale . '.name'); ?></label>
            <input type="text" class="form-control <?php $__errorArgs = [$locale . ' .name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> " name=" <?php echo e($locale); ?>[name]"
                value="<?php echo e(isset($row) ? $row->translate($locale)->name : old($locale . '.name')); ?>">

            <?php $__errorArgs = [$locale . '.name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <small class=" text text-danger" role="alert">
                <strong><?php echo e($message); ?></strong>
            </small>
            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<div class="form-group col-md-6">
    <div class="text-bold-600 font-medium-2">
        <?php echo app('translator')->get('site.areas'); ?>
    </div>
    <select class="select2 form-control <?php $__errorArgs = [$locale . ' .parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
            id="area_id" name="parent_id"
    >
        <optgroup label="<?php echo app('translator')->get('site.select'); ?>">
            <option></option>
            <?php $__empty_1 = true; $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <option value="<?php echo e($area->id); ?>" 
                    <?php echo e(isset($row) && $row->id == $area->id  ? 'selected' : ''); ?> >
                    <?php echo e($area->name); ?>

                </option>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <option></option>
            <?php endif; ?>
        </optgroup>
    </select>

    <?php $__errorArgs = [$locale . '.parent_id'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class=" text text-danger" role="alert">
        <strong><?php echo e($message); ?></strong>
    </small>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\xampp\htdocs\drugly\resources\views/dashboard/areas/form.blade.php ENDPATH**/ ?>